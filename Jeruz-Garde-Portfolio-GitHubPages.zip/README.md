# Engr. Jeruz Garde — Developer Portfolio

A modern, premium, fully responsive developer portfolio built with **plain HTML, CSS, and vanilla
JavaScript** — no build step, no Node.js, no bundler. It runs by simply opening `index.html` and
deploys to **GitHub Pages** with zero configuration.

**Live demo:** _add your GitHub Pages URL here after deploying_

---

## ✨ Features

- Dark-mode-first design with a light theme toggle (remembers your choice)
- Animated aurora background, glassmorphism cards, gradient accents
- Sections: Home · About · Projects · Skills · Services · Contact
- Interactive **project gallery** with category filters and a detail **modal**
  (overview, key features, demo video, screenshots, live + code links)
- Scroll-reveal animations and animated skill bars (IntersectionObserver)
- Lazy-loaded images and video (`loading="lazy"`, `preload="none"`)
- `mailto`-based contact form (no backend needed)
- Semantic HTML5, accessible focus states, responsive on desktop / tablet / mobile
- Only one external resource: Google Fonts (Inter) via CDN

---

## 📁 Project structure

```
/
├── index.html            → the entire site (single entry point)
├── css/
│   └── styles.css        → all styles + design tokens (light/dark)
├── js/
│   └── script.js         → data, rendering, filters, modal, theme, nav, form
├── assets/
│   ├── images/           → profile photo + project screenshots
│   ├── videos/           → Snow Bear demo video
│   └── docs/             → portfolio PDF
└── README.md
```

All paths are **relative**, so the site works from any sub-folder (e.g. `username.github.io/portfolio/`).

---

## 🚀 Deploy to GitHub Pages

### Option A — Web upload (no Git needed)
1. Create a new repository on GitHub (e.g. `portfolio`).
2. Click **Add file → Upload files**, drag in **all files and folders** from this project
   (keep the folder structure — `index.html` must be at the repository root).
3. Commit.
4. Go to **Settings → Pages**.
5. Under **Build and deployment → Source**, choose **Deploy from a branch**.
6. Select branch **`main`** and folder **`/ (root)`**, then **Save**.
7. Wait ~1 minute. Your live demo appears at:
   `https://<your-username>.github.io/<repo-name>/`

### Option B — Git command line
```bash
git init
git add .
git commit -m "Portfolio site"
git branch -M main
git remote add origin https://github.com/<your-username>/<repo-name>.git
git push -u origin main
```
Then enable Pages as in steps 4–7 above.

> **Tip:** to serve it at `https://<your-username>.github.io/` (no sub-path), name the
> repository exactly `<your-username>.github.io`.

---

## 💻 Run locally

Just **double-click `index.html`** — it opens in any modern browser (Chrome, Edge, Firefox, Safari).

_Optional_ (only if your browser blocks the demo video over `file://`), run a tiny static server:
```bash
# Python 3
python -m http.server 8000
# then open http://localhost:8000
```

---

## 🛠 Customize

- **Text, projects, skills, services** → edit the data objects near the top of `js/script.js`
  (`SITE`, `PROJECTS`, `SKILL_GROUPS`, `SERVICES`, `EXPERIENCE`).
- **Colors & spacing** → edit the CSS variables in `:root` (and `[data-theme="light"]`) in `css/styles.css`.
- **Photo** → replace `assets/images/Profile.jpg`.
- **PDF / CV** → replace `assets/docs/Jeruz-Garde-Portfolio.pdf`.

---

## 📬 Contact

- **Email:** jeruzgarde@gmail.com
- **Phone:** 0961 417 0201
- **GitHub:** [github.com/darkhorsepig](https://github.com/darkhorsepig)

_Pricing is always flexible and negotiable._

© Jeruz Laynell J. Garde
