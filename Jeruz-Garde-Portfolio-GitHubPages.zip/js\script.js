/* =========================================================
   Engr. Jeruz Garde — Portfolio  ·  vanilla JS
   ========================================================= */
(function () {
  "use strict";

  /* ---------- Site data ---------- */
  var SITE = {
    name: "Engr. Jeruz Garde",
    fullName: "Jeruz Laynell J. Garde",
    role: "Computer Engineer & Full-Stack Developer",
    email: "jeruzgarde@gmail.com",
    phone: "09614170201",
    messenger: "Jeruz Garde",
    location: "Maasin City, Southern Leyte, Philippines",
    github: "https://github.com/darkhorsepig",
    cv: "assets/docs/Jeruz-Garde-Portfolio.pdf"
  };

  /* ---------- Projects (ported from the Next.js data) ---------- */
  var PROJECTS = [
    {
      slug: "snow-bear-courtos", title: "Snow Bear CourtOS", tagline: "Court Booking & Management SaaS",
      category: "SaaS Platform", status: "Completed", featured: true, year: "2026",
      description: "A complete SaaS platform for court facilities: no-sign-up online booking, online payments, open play, tournaments, and a full owner dashboard.",
      tech: ["Node.js", "Express", "PostgreSQL", "JWT", "Bootstrap 5", "Chart.js"],
      thumbnail: "assets/images/snowbear-home.jpg",
      screenshots: [
        { src: "assets/images/snowbear-home.jpg", caption: "Branded customer landing page" },
        { src: "assets/images/snowbear-booking.png", caption: "No-sign-up booking with live color-coded slots" },
        { src: "assets/images/snowbear-dashboard.png", caption: "Owner dashboard with revenue & usage analytics" },
        { src: "assets/images/snowbear-payments.png", caption: "Payment verification & official receipts" },
        { src: "assets/images/snowbear-tournaments.png", caption: "Tournaments with online registration" },
        { src: "assets/images/snowbear-openplay.png", caption: "Open Play scheduling" }
      ],
      video: "assets/videos/snowbear-demo.mp4",
      github: SITE.github, live: "",
      overview: "Snow Bear CourtOS is a production-ready, multi-tenant platform that lets a facility take bookings and payments online while managing the whole business from one dashboard. Each company gets its own branded booking site, isolated data, and a subscription managed by a super admin.",
      features: [
        "No-sign-up guest booking with live, color-coded time slots",
        "Online payments (GCash / BDO Pay / Maya) with proof upload & receipts",
        "Open Play sessions and Tournament mode with paid registration",
        "Owner dashboard: revenue, court-usage & peak-hour analytics",
        "Editable operating hours, contact, payment settings & court photos",
        "Multi-tenant super admin with subscription plans & feature gating"
      ],
      stats: [
        { label: "Interfaces", value: "Customer + Admin + Super Admin" },
        { label: "Admin modules", value: "10+" },
        { label: "Payment methods", value: "3" },
        { label: "Architecture", value: "Multi-tenant" }
      ]
    },
    {
      slug: "apex-aerial-ph", title: "Apex Aerial PH", tagline: "Aerial Photography & Videography · Drone Service",
      category: "Aerial Media", status: "Completed", featured: true, year: "2025",
      description: "My own aerial media business — capturing events, real estate, and promotional content from the sky with a DJI Mini 5 Pro, plus cinematic editing and social-media management.",
      tech: ["DJI Mini 5 Pro", "4K Aerial", "Video Editing", "Social Media"],
      thumbnail: "assets/images/drone-apex-poster.jpg",
      screenshots: [{ src: "assets/images/drone-apex-poster.jpg", caption: "Apex Aerial PH — Capture the View Above" }],
      videos: [
        { src: "assets/videos/drone-cinematic-1.mp4", caption: "Cinematic aerial reel" },
        { src: "assets/videos/drone-yen2.mp4", caption: "4K aerial portrait shoot" },
        { src: "assets/videos/drone-wedding-1.mp4", caption: "Wedding aerial coverage" },
        { src: "assets/videos/drone-wedding-couple.mp4", caption: "Wedding couple — aerial" },
        { src: "assets/videos/drone-wedding-2.mp4", caption: "Wedding highlights" },
        { src: "assets/videos/drone-wedding-all.mp4", caption: "Full wedding aerials" },
        { src: "assets/videos/drone-commercial-1.mp4", caption: "Commercial / promo" },
        { src: "assets/videos/drone-sample-1.mp4", caption: "Aerial sample shots" },
        { src: "assets/videos/drone-tiktok-1.mp4", caption: "Social / TikTok short" }
      ],
      github: "", live: "",
      overview: "Apex Aerial PH is my aerial media business. I capture events, properties, and business projects from the sky using a DJI Mini 5 Pro, then edit cinematic reels and short-form social content. I also run the brand and manage its Facebook page — from shooting and editing to posting and client coordination.",
      features: [
        "4K aerial photography & videography",
        "Wedding & event aerial coverage",
        "Real-estate & resort showcases",
        "Cinematic promotional reels",
        "TikTok / social-media short content",
        "Brand & Facebook page management"
      ],
      stats: [
        { label: "Focus", value: "Aerial photo & video" },
        { label: "Gear", value: "DJI Mini 5 Pro" },
        { label: "Coverage", value: "Events · Real estate · Promo" },
        { label: "Based in", value: "Southern Leyte, PH" }
      ]
    },

    {
      slug: "corencore-life", title: "Corencore Life", tagline: "Technical Services Company Website — Dubai",
      category: "Website", status: "Completed", featured: true, year: "2025",
      description: "A bold, editorial corporate website for a Dubai technical-services and fit-out company, with a blueprint-inspired design system and smooth scroll interactions.",
      tech: ["HTML5", "CSS3", "JavaScript", "GSAP", "Responsive Design"],
      thumbnail: "assets/images/web-corencore.jpg",
      screenshots: [{ src: "assets/images/web-corencore.jpg", caption: "Hero — Design Art. Engineering Science. Dedicated to Life." }],
      github: "https://github.com/darkhorsepig/Core-N-Core", live: "https://darkhorsepig.github.io/Core-N-Core/",
      overview: "Corencore Life is a corporate site for a Dubai-based technical-services, architecture, and renovation company. The design leans into a technical/blueprint aesthetic — grid backdrops, engineering annotations, and confident typography.",
      features: ["Editorial hero with blueprint motif", "Sectioned About / Services / Projects / Gallery / Contact", "Smooth scroll & reveal animations", "Fully responsive layout", "Hosted on GitHub Pages"],
      stats: [{ label: "Type", value: "Corporate website" }, { label: "Location", value: "Dubai, UAE" }, { label: "Hosting", value: "GitHub Pages" }]
    },
    {
      slug: "uppal-luxury", title: "Uppal Housing — Luxury Edition", tagline: "Ultra-Luxury Real Estate — Dubai",
      category: "Website", status: "Completed", featured: true, year: "2025",
      description: "An elegant, cinematic landing site for Uppal Housing Development, a luxury UAE real-estate brand — full-bleed imagery, serif display type, and gold accents.",
      tech: ["HTML5", "CSS3", "JavaScript", "Responsive Design"],
      thumbnail: "assets/images/web-uppal-luxury.jpg",
      screenshots: [{ src: "assets/images/web-uppal-luxury.jpg", caption: "Cinematic hero — Crafting landmarks of enduring value" }],
      github: "https://github.com/darkhorsepig/Luxury-Brand-Uppal", live: "https://darkhorsepig.github.io/Luxury-Brand-Uppal/",
      overview: "A luxury brand website for Uppal Housing Development (est. 1979, Downtown Dubai). The design emphasizes restraint and prestige — large architectural photography, refined serif headlines, and subtle gold detailing.",
      features: ["Full-bleed architectural hero", "Refined serif + gold accent design system", "About / Legacy / Residences sections", "Enquiry-focused calls to action", "Responsive across devices"],
      stats: [{ label: "Sector", value: "Luxury real estate" }, { label: "Location", value: "Dubai, UAE" }, { label: "Hosting", value: "GitHub Pages" }]
    },
    {
      slug: "uppal-premium", title: "Uppal Housing — Premium Edition", tagline: "Premium Real-Estate Landing",
      category: "Website", status: "Completed", featured: false, year: "2025",
      description: "An alternate premium design direction for Uppal Housing Development — a second concept exploring layout, motion, and brand expression for the same developer.",
      tech: ["HTML5", "CSS3", "JavaScript", "Responsive Design"],
      thumbnail: "assets/images/web-uppal-premium.jpg",
      screenshots: [{ src: "assets/images/web-uppal-premium.jpg", caption: "Premium concept — Uppal Housing Development" }],
      github: "https://github.com/darkhorsepig/Premium-Uppal", live: "https://darkhorsepig.github.io/Premium-Uppal/",
      overview: "A second, premium design concept for Uppal Housing Development — exploring a different layout and motion language while staying true to the brand's prestige.",
      features: ["Alternate premium hero & layout", "Distinct section flow", "Motion & hover interactions", "Responsive design", "Live on GitHub Pages"],
      stats: [{ label: "Type", value: "Design concept" }, { label: "Sector", value: "Real estate" }, { label: "Hosting", value: "GitHub Pages" }]
    },
    {
      slug: "ecommerce-website", title: "E-Commerce Website", tagline: "Online Store — Shop, Cart & Admin",
      category: "Website", status: "Completed", featured: false, year: "2024",
      description: "A full e-commerce web application with product catalog, user accounts, shopping cart, checkout, order tracking, and an admin dashboard for managing products and orders.",
      tech: ["HTML5", "CSS3", "JavaScript", "PHP", "MySQL"],
      thumbnail: "assets/images/shop-home.jpg",
      screenshots: [
        { src: "assets/images/shop-home.jpg", caption: "Storefront home page" },
        { src: "assets/images/shop-store.jpg", caption: "Product catalog / shop" },
        { src: "assets/images/shop-dashboard.jpg", caption: "Admin dashboard" },
        { src: "assets/images/shop-addproduct.jpg", caption: "Add / manage products" },
        { src: "assets/images/shop-checkout.jpg", caption: "Cart & checkout" },
        { src: "assets/images/shop-order.jpg", caption: "Order management" },
        { src: "assets/images/shop-useracc.jpg", caption: "User account" }
      ],
      github: SITE.github, live: "",
      overview: "A complete online store: customers browse products, register and manage an account, add to cart, and check out; while an admin manages products, stock, and orders from a dashboard.",
      features: ["Product catalog & search", "User registration & accounts", "Shopping cart & checkout", "Order placement & tracking", "Admin product & stock management", "Order management dashboard"],
      stats: [{ label: "Type", value: "E-commerce web app" }, { label: "Roles", value: "Customer · Admin" }, { label: "Stack", value: "PHP · MySQL" }]
    },

    {
      slug: "web-design", title: "Web Design Projects", tagline: "Landing Pages & Business Sites",
      category: "Website", status: "Completed", featured: false, year: "2024",
      description: "A selection of responsive website designs — a car dealership landing page and a local city/community site — focused on clean layout and clear calls to action.",
      tech: ["HTML5", "CSS3", "JavaScript", "Responsive Design"],
      thumbnail: "assets/images/web-car.jpg",
      screenshots: [
        { src: "assets/images/web-car.jpg", caption: "Car dealership website" },
        { src: "assets/images/web-maasin.jpg", caption: "Maasin community website" }
      ],
      github: SITE.github, live: "",
      overview: "A set of responsive front-end website designs built with HTML, CSS, and JavaScript — demonstrating layout, branding, and responsive design across different industries.",
      features: ["Responsive layouts", "Clean, modern UI", "Hero & call-to-action sections", "Cross-device compatibility", "Reusable components"],
      stats: [{ label: "Type", value: "Web design" }, { label: "Projects", value: "2 sites" }, { label: "Focus", value: "Responsive UI" }]
    },

    {
      slug: "threed-rendering", title: "3D Rendering & CAD Design", tagline: "AutoCAD, 3D Modeling & Rendering",
      category: "3D & CAD", status: "Completed", featured: true, year: "2025",
      description: "Technical and architectural 3D work — floor plans, house renders, product models, and electronics — created with CAD and 3D modeling tools.",
      tech: ["AutoCAD", "3D Modeling", "Rendering", "Technical Design"],
      thumbnail: "assets/images/threed-house.jpg",
      screenshots: [
        { src: "assets/images/threed-house.jpg", caption: "House render" },
        { src: "assets/images/threed-floorplan.jpg", caption: "Housing floor plan" },
        { src: "assets/images/threed-storage.jpg", caption: "Storage house model" },
        { src: "assets/images/threed-headphones.jpg", caption: "Product model — headphones" },
        { src: "assets/images/threed-resistor.jpg", caption: "Electronics — 3D resistor" }
      ],
      github: "", live: "",
      overview: "A portfolio of 3D and CAD work spanning architecture (floor plans and house renders), product design (headphones), and electronics (component modeling) — showing precision drafting and rendering skills alongside my engineering background.",
      features: ["Architectural floor plans", "3D house & structure renders", "Product / industrial modeling", "Electronics component design", "Technical drafting & layouts"],
      stats: [{ label: "Type", value: "3D & CAD" }, { label: "Tools", value: "AutoCAD · 3D modeling" }, { label: "Range", value: "Architecture · Product · Electronics" }]
    },

    {
      slug: "pensione-pos", title: "Pensione POS", tagline: "Room & Retail POS System",
      category: "Desktop System", status: "Completed", featured: false, year: "2025",
      description: "A point-of-sale system for a pension house — live room-status board with timers and add-ons, product inventory, cashier flow, and sales reports.",
      tech: ["VB.NET", "Windows Forms", "MySQL"],
      thumbnail: "assets/images/pensione-menu.jpg",
      screenshots: [
        { src: "assets/images/pensione-menu.jpg", caption: "Main POS menu" },
        { src: "assets/images/pensione-product.jpg", caption: "Product management" },
        { src: "assets/images/pensione-stock.jpg", caption: "Update stock inventory" },
        { src: "assets/images/pensione-inventory.jpg", caption: "Inventory report" },
        { src: "assets/images/pensione-report.jpg", caption: "Sales report form" }
      ],
      github: SITE.github, live: "",
      overview: "A desktop POS built for a pension house to manage room occupancy, add-ons, product sales, and daily reporting — with admin and cashier roles.",
      features: ["Live room status with timers & add-on rates", "Product inventory management", "Cashier & admin roles", "Sales & inventory reports with export", "Printable receipts"],
      stats: [{ label: "Type", value: "Desktop POS" }, { label: "Roles", value: "Admin · Cashier" }, { label: "Reports", value: "Sales · Inventory" }]
    },
    {
      slug: "medrecords360", title: "MedRecords360", tagline: "Medical Records Management System",
      category: "Desktop System", status: "Completed", featured: false, year: "2024",
      description: "A desktop system for managing patient medical records — staff accounts, patient registration, health history, and summary reports.",
      tech: ["VB.NET", "Windows Forms", "MySQL"],
      thumbnail: "assets/images/medrecords-1.jpg",
      screenshots: [
        { src: "assets/images/medrecords-1.jpg", caption: "Patient records dashboard" },
        { src: "assets/images/medrecords-2.jpg", caption: "Patient history & summary" }
      ],
      github: SITE.github, live: "",
      overview: "MedRecords360 digitizes patient records for a clinic — staff accounts, patient registration with full history, searchable records, and summary reports.",
      features: ["Secure staff accounts & login", "Patient registration & profiles", "Family & present health history", "Searchable records list", "Summary & printable reports"],
      stats: [{ label: "Type", value: "Records system" }, { label: "Users", value: "Medical staff" }, { label: "Output", value: "Summary reports" }]
    },
    {
      slug: "gym-management", title: "Gym Management System", tagline: "Members, Plans, Trainers & Records",
      category: "Desktop System", status: "Completed", featured: false, year: "2024",
      description: "A desktop management system for a gym — members, workout plans, packages, trainers, products, and earnings records with a live dashboard.",
      tech: ["VB.NET", "Windows Forms", "MySQL"],
      thumbnail: "assets/images/gym-1.jpg",
      screenshots: [
        { src: "assets/images/gym-1.jpg", caption: "Dashboard — members & earnings" },
        { src: "assets/images/gym-2.jpg", caption: "Member management" },
        { src: "assets/images/gym-3.jpg", caption: "Workout plans & packages" },
        { src: "assets/images/gym-4.jpg", caption: "Trainers & products" },
        { src: "assets/images/gym-5.jpg", caption: "Records & reports" }
      ],
      github: SITE.github, live: "",
      overview: "A complete gym back-office: manage members, workout plans and packages, trainers, and products, with a dashboard showing active members and earnings.",
      features: ["Member management", "Workout plans & packages", "Trainer directory & rates", "Products & records", "Dashboard: members, trainers & earnings"],
      stats: [{ label: "Type", value: "Management system" }, { label: "Modules", value: "Members · Plans · Trainers" }, { label: "Dashboard", value: "Yes" }]
    },
    {
      slug: "senior-citizen-tracker", title: "Senior Citizen Age Tracker", tagline: "Barangay Senior-Citizen Records",
      category: "Desktop System", status: "Completed", featured: false, year: "2024",
      description: "A local-government system for a barangay to register and track senior citizens, with role-based logins and a records dashboard.",
      tech: ["VB.NET", "Windows Forms", "MySQL"],
      thumbnail: "assets/images/senior-1.jpg",
      screenshots: [{ src: "assets/images/senior-1.jpg", caption: "Senior-citizen records & dashboard design" }],
      github: SITE.github, live: "",
      overview: "Built for Barangay Concepcion (Sogod, Southern Leyte) to register senior citizens and track records, with roles for Secretary, Barangay Captain, and Health Worker.",
      features: ["Role-based login (Secretary / Captain / Health Worker)", "Add & update senior records", "Master list & dashboard", "Overview statistics", "Government-ready workflow"],
      stats: [{ label: "Type", value: "LGU system" }, { label: "Roles", value: "3" }, { label: "For", value: "Barangay" }]
    },

    {
      slug: "barangay-registration", title: "Barangay Registration System", tagline: "Resident Registration & Records",
      category: "Desktop System", status: "Completed", featured: false, year: "2024",
      description: "A local-government desktop system for registering barangay residents and managing their records, with a clean form-based interface.",
      tech: ["VB.NET", "Windows Forms", "MySQL"],
      thumbnail: "assets/images/barangay-1.jpg",
      screenshots: [
        { src: "assets/images/barangay-1.jpg", caption: "Registration interface" },
        { src: "assets/images/barangay-2.jpg", caption: "Records management" }
      ],
      github: SITE.github, live: "",
      overview: "A desktop registration system for a barangay (local government unit) to register residents, capture their details, and manage records — streamlining what used to be a manual, paper-based process.",
      features: ["Resident registration & profiles", "Records management", "Search & update records", "Form-based data entry", "Government-ready workflow"],
      stats: [{ label: "Type", value: "LGU system" }, { label: "Purpose", value: "Resident registration" }, { label: "Stack", value: "VB.NET · MySQL" }]
    },

    {
      slug: "children-health", title: "Children Health Management System", tagline: "Child Health Records & Monitoring",
      category: "Desktop System", status: "Completed", featured: false, year: "2024",
      description: "A health-records system for monitoring children's health data and records, built for local health workers.",
      tech: ["VB.NET", "Windows Forms", "MySQL"],
      thumbnail: "assets/images/children-health.jpg",
      screenshots: [{ src: "assets/images/children-health.jpg", caption: "Children health management interface" }],
      github: SITE.github, live: "",
      overview: "A desktop system to record and monitor children's health information for a local health center — helping health workers keep organized, searchable records instead of paper logs.",
      features: ["Child health records", "Registration & profiles", "Health monitoring data", "Searchable records", "Reports for health workers"],
      stats: [{ label: "Type", value: "Health records" }, { label: "Users", value: "Health workers" }, { label: "Stack", value: "VB.NET · MySQL" }]
    }
  ];

  var SKILL_GROUPS = [
    { name: "Languages", skills: [["JavaScript / TypeScript", 90], ["Python", 85], ["Java", 84], ["C# / .NET", 82], ["SQL", 86]] },
    { name: "Web & Frameworks", skills: [["React / Next.js", 92], ["Django", 82], ["Node.js / Express", 88], ["Tailwind CSS", 93], ["REST API design", 90]] },
    { name: "Databases & Desktop", skills: [["MySQL", 85], ["PostgreSQL", 86], ["SQL Server", 80], ["C# WinForms", 82], ["Raspberry Pi / IoT", 75]] },
    { name: "Networking", skills: [["LAN/WAN & TCP/IP", 88], ["IPv4 subnetting", 86], ["VLANs, routing & switching", 84], ["DHCP / DNS / wireless", 83], ["Structured cabling (T568A/B)", 85]] },
    { name: "Network Security", skills: [["Firewalls & access control", 82], ["Network hardening", 80], ["Packet inspection", 82], ["Information assurance", 84]] },
    { name: "Tools & Practices", skills: [["Cisco Packet Tracer", 88], ["Wireshark", 82], ["Git & GitHub", 90], ["AutoCAD / 3D", 78], ["Video editing", 84]] }
  ];

  var SERVICES = [
    { icon: "globe", title: "Web Development", desc: "Fast, responsive, SEO-friendly websites and landing pages — frontend and backend.", items: ["Responsive UI", "SEO metadata", "Contact & lead forms"] },
    { icon: "layers", title: "System & App Development", desc: "Systems tailored to business needs — POS, dashboards, and automation tools.", items: ["Custom modules", "Role-based access", "Cloud or desktop"] },
    { icon: "calendar", title: "Booking Systems", desc: "Online booking platforms with live availability, payments, and confirmations.", items: ["Live slot booking", "Online payments", "Email confirmations"] },
    { icon: "dashboard", title: "Admin Dashboards", desc: "Owner dashboards with analytics, management tools, and exportable reports.", items: ["Charts & KPIs", "CRUD management", "CSV / print reports"] },
    { icon: "database", title: "Database Management", desc: "I design and manage databases (MySQL, PostgreSQL) for secure, optimized data.", items: ["Schema design", "Optimization", "Backups & security"] },
    { icon: "cpu", title: "Automation & AI Integration", desc: "Automation and AI-assisted features that streamline workflows and boost efficiency.", items: ["Workflow automation", "AI features", "Integrations"] },
    { icon: "pen", title: "AutoCAD Drafting & Design", desc: "Precise 2D/3D drawings, layouts, and technical plans for engineering & architecture.", items: ["2D floor plans", "3D models", "Technical layouts"] },
    { icon: "video", title: "Graphics & Video Editing", desc: "Branding, social graphics, posters, and short-form video content.", items: ["Branding & posters", "Social graphics", "Reels & short videos"] },
    { icon: "drone", title: "Aerial Drone Services", desc: "Aerial photography & videography for events, real estate, and promos — captured with a DJI Mini 5 Pro (Apex Aerial PH).", items: ["4K aerial photo & video", "Events & real estate", "Cinematic promo reels"] }
  ];

  var EXPERIENCE = [
    { when: "2025 — 2027", role: "IT College Instructor", org: "College of Maasin · Southern Leyte, Philippines",
      points: ["Teach Computer Programming 1 & 2, Object-Oriented Programming (Java), Computer Networking, Hardware Systems & Servicing, and Information Assurance & Security.", "Design course materials, programming assignments, practical exams, and hands-on lab activities."] },
    { when: "2025 — Present", role: "Founder & Aerial Content Creator", org: "Apex Aerial PH · Drone Services",
      points: ["Run my own aerial photography & videography business using a DJI Mini 5 Pro.", "Shoot and edit cinematic reels for weddings, real estate, resorts, and promos — and manage the brand's Facebook page & social content."] },
    { when: "2024 — Present", role: "Full-Stack Developer (Freelance)", org: "Independent / Client projects",
      points: ["Designed and shipped Snow Bear CourtOS, a multi-tenant booking SaaS.", "Built luxury brand & corporate websites (Uppal Housing, Corencore Life — Dubai).", "Delivered POS and management systems for private companies and government (LGU)."] },
    { when: "Graduate", role: "BS in Computer Engineering", org: "Southern Leyte State University · Sogod, Southern Leyte",
      points: ["Professional Computer Engineer with a strong software, systems & networking foundation.", "600-hour OJT: computer assembly, software installation & networking."] }
  ];

  /* ---------- Inline SVG icons ---------- */
  var ICON = {
    arrow: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>',
    arrowUp: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="7" y1="17" x2="17" y2="7"/><polyline points="7 7 17 7 17 17"/></svg>',
    top: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="19" x2="12" y2="5"/><polyline points="5 12 12 5 19 12"/></svg>',
    mail: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 7-10 5L2 7"/></svg>',
    phone: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6 19.8 19.8 0 0 1-3.1-8.7A2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1.9.4 1.8.7 2.7a2 2 0 0 1-.5 2.1L8.1 9.9a16 16 0 0 0 6 6l1.4-1.2a2 2 0 0 1 2.1-.5c.9.3 1.8.6 2.7.7a2 2 0 0 1 1.7 2Z"/></svg>',
    pin: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg>',
    github: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 .5A11.5 11.5 0 0 0 .5 12 11.5 11.5 0 0 0 8.4 23c.6.1.8-.3.8-.6v-2c-3.2.7-3.9-1.4-3.9-1.4-.5-1.3-1.3-1.7-1.3-1.7-1.1-.7.1-.7.1-.7 1.2.1 1.8 1.2 1.8 1.2 1 1.8 2.8 1.3 3.5 1 .1-.8.4-1.3.7-1.6-2.6-.3-5.3-1.3-5.3-5.7 0-1.3.5-2.3 1.2-3.1-.1-.3-.5-1.5.1-3.1 0 0 1-.3 3.3 1.2a11.5 11.5 0 0 1 6 0C17.3 4.7 18.3 5 18.3 5c.6 1.6.2 2.8.1 3.1.8.8 1.2 1.8 1.2 3.1 0 4.4-2.7 5.4-5.3 5.7.4.4.8 1.1.8 2.2v3.3c0 .3.2.7.8.6A11.5 11.5 0 0 0 23.5 12 11.5 11.5 0 0 0 12 .5Z"/></svg>',
    external: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>',
    play: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polygon points="10 8 16 12 10 16 10 8" fill="currentColor"/></svg>',
    star: '<svg viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15 9 22 9.3 16.5 14 18.3 21 12 17 5.7 21 7.5 14 2 9.3 9 9"/></svg>',
    close: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>',
    sun: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg>',
    moon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8Z"/></svg>',
    menu: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="18" x2="21" y2="18"/></svg>',
    download: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>',
    sparkles: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l1.6 4.4L18 8l-4.4 1.6L12 14l-1.6-4.4L6 8l4.4-1.6L12 2z"/></svg>',
    code: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/></svg>',
    db: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M3 5v14c0 1.7 4 3 9 3s9-1.3 9-3V5"/><path d="M3 12c0 1.7 4 3 9 3s9-1.3 9-3"/></svg>',
    layout: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M9 21V9"/></svg>',
    globe: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M2 12h20M12 2a15 15 0 0 1 0 20 15 15 0 0 1 0-20Z"/></svg>',
    layers: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 2 7 12 12 22 7 12 2"/><polyline points="2 17 12 22 22 17"/><polyline points="2 12 12 17 22 12"/></svg>',
    calendar: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/></svg>',
    dashboard: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="9"/><rect x="14" y="3" width="7" height="5"/><rect x="14" y="12" width="7" height="9"/><rect x="3" y="16" width="7" height="5"/></svg>',
    cpu: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="4" width="16" height="16" rx="2"/><rect x="9" y="9" width="6" height="6"/><path d="M9 1v3M15 1v3M9 20v3M15 20v3M20 9h3M20 14h3M1 9h3M1 14h3"/></svg>',
    pen: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 19l7-7 3 3-7 7-3-3z"/><path d="M18 13l-1.5-7.5L2 2l3.5 14.5L13 18l5-5z"/><path d="M2 2l7.586 7.586"/><circle cx="11" cy="11" r="2"/></svg>',
    video: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m23 7-7 5 7 5V7z"/><rect x="1" y="5" width="15" height="14" rx="2"/></svg>',
    drone: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="6" height="6" rx="1"/><path d="M9 9 5.5 5.5M15 9l3.5-3.5M9 15l-3.5 3.5M15 15l3.5 3.5"/><circle cx="4" cy="4" r="2.2"/><circle cx="20" cy="4" r="2.2"/><circle cx="4" cy="20" r="2.2"/><circle cx="20" cy="20" r="2.2"/></svg>',
    facebook: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M22 12a10 10 0 1 0-11.6 9.9v-7H7.9V12h2.5V9.8c0-2.5 1.5-3.9 3.8-3.9 1.1 0 2.2.2 2.2.2v2.5h-1.3c-1.2 0-1.6.8-1.6 1.6V12h2.8l-.4 2.9h-2.3v7A10 10 0 0 0 22 12Z"/></svg>'
  };

  /* ---------- Helpers ---------- */
  function el(html) { var t = document.createElement("template"); t.innerHTML = html.trim(); return t.content.firstChild; }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); }
  function $(sel, ctx) { return (ctx || document).querySelector(sel); }
  function $all(sel, ctx) { return Array.prototype.slice.call((ctx || document).querySelectorAll(sel)); }

  /* ---------- Render: projects ---------- */
  function projectCard(p) {
    var techChips = p.tech.slice(0, 4).map(function (t) { return '<span class="chip">' + esc(t) + "</span>"; }).join("");
    if (p.tech.length > 4) techChips += '<span class="chip">+' + (p.tech.length - 4) + "</span>";
    var live = p.live ? '<a class="btn btn-ghost btn-sm" href="' + p.live + '" target="_blank" rel="noreferrer" title="Live demo" onclick="event.stopPropagation()">' + ICON.external + "</a>" : "";
    var gh = p.github ? '<a class="btn btn-ghost btn-sm" href="' + p.github + '" target="_blank" rel="noreferrer" title="GitHub" onclick="event.stopPropagation()">' + ICON.github + "</a>" : "";
    var vidBtn = (p.videos && p.videos.length) ? '<span class="btn btn-ghost btn-sm" title="' + p.videos.length + ' videos">' + ICON.play + "</span>" : "";
    return el(
      '<article class="card project-card reveal" data-category="' + esc(p.category) + '" data-slug="' + p.slug + '">' +
        '<div class="thumb">' +
          '<img loading="lazy" src="' + p.thumbnail + '" alt="' + esc(p.title) + '">' +
          (p.featured ? '<span class="tag-featured">' + ICON.star + " Featured</span>" : "") +
          '<span class="tag-status">' + esc(p.status) + "</span>" +
        "</div>" +
        '<div class="body">' +
          '<div class="meta"><span class="chip">' + esc(p.category) + '</span><span class="chip">' + esc(p.year) + "</span></div>" +
          "<h3>" + esc(p.title) + "</h3>" +
          "<p>" + esc(p.description) + "</p>" +
          '<div class="techrow">' + techChips + "</div>" +
          '<div class="actions">' +
            '<button class="btn btn-primary btn-sm view-btn">View Details ' + ICON.arrowUp + "</button>" +
            live + vidBtn + gh +
          "</div>" +
        "</div>" +
      "</article>"
    );
  }

  function renderProjects(filter) {
    var grid = $("#projects-grid");
    grid.innerHTML = "";
    PROJECTS.filter(function (p) { return !filter || filter === "All" || p.category === filter; })
      .forEach(function (p) {
        var card = projectCard(p);
        card.addEventListener("click", function () { openModal(p.slug); });
        grid.appendChild(card);
      });
    observeReveals();
  }

  function renderFilters() {
    var cats = ["All"].concat(PROJECTS.map(function (p) { return p.category; }).filter(function (v, i, a) { return a.indexOf(v) === i; }));
    var wrap = $("#filters");
    cats.forEach(function (c, i) {
      var b = el('<button class="filter-btn' + (i === 0 ? " active" : "") + '">' + esc(c) + "</button>");
      b.addEventListener("click", function () {
        $all(".filter-btn").forEach(function (x) { x.classList.remove("active"); });
        b.classList.add("active");
        renderProjects(c);
      });
      wrap.appendChild(b);
    });
  }

  /* ---------- Modal ---------- */
  function openModal(slug) {
    var p = PROJECTS.find(function (x) { return x.slug === slug; });
    if (!p) return;
    var stats = p.stats.map(function (s) { return '<div class="st"><div class="v">' + esc(s.value) + '</div><div class="l">' + esc(s.label) + "</div></div>"; }).join("");
    var feats = p.features.map(function (f) { return "<li>" + esc(f) + "</li>"; }).join("");
    var shots = p.screenshots.map(function (s) {
      return '<figure><img loading="lazy" src="' + s.src + '" alt="' + esc(s.caption) + '"><figcaption>' + esc(s.caption) + "</figcaption></figure>";
    }).join("");
    var video = p.video ? '<video class="modal-video" controls preload="none" poster="' + p.thumbnail + '"><source src="' + p.video + '" type="video/mp4"></video>' : "";
    var videoGrid = (p.videos && p.videos.length) ? p.videos.map(function (v) {
      return '<figure><video controls preload="none" playsinline><source src="' + v.src + '" type="video/mp4"></video><figcaption>' + esc(v.caption) + "</figcaption></figure>";
    }).join("") : "";
    var actions = "";
    if (p.live) actions += '<a class="btn btn-primary" href="' + p.live + '" target="_blank" rel="noreferrer">Visit Live Site ' + ICON.external + "</a>";
    if (p.github) actions += '<a class="btn btn-ghost" href="' + p.github + '" target="_blank" rel="noreferrer">View Code ' + ICON.github + "</a>";
    if (p.slug === "apex-aerial-ph") actions += '<a class="btn btn-primary" href="mailto:jeruzgarde@gmail.com?subject=' + encodeURIComponent("Apex Aerial PH — Drone booking") + '">Book a Shoot ' + ICON.mail + "</a>";

    $("#modal").innerHTML =
      '<div class="modal-hero"><img src="' + p.thumbnail + '" alt="' + esc(p.title) + '">' +
        '<button class="modal-close" aria-label="Close">' + ICON.close + "</button></div>" +
      '<div class="modal-body">' +
        '<div class="tagline">' + esc(p.tagline) + "</div>" +
        "<h2>" + esc(p.title) + "</h2>" +
        '<p class="desc">' + esc(p.overview) + "</p>" +
        '<div class="modal-stats">' + stats + "</div>" +
        "<h4>Key features</h4><ul class=\"feat-list\">" + feats + "</ul>" +
        (videoGrid ? "<h4>Aerial showreel</h4><div class=\"modal-videos\">" + videoGrid + "</div>" : "") +
        (video ? "<h4>Demo video</h4>" + video : "") +
        (p.screenshots.length ? "<h4>Screens</h4><div class=\"modal-shots\">" + shots + "</div>" : "") +
        '<div class="modal-actions">' + actions + "</div>" +
      "</div>";
    $("#modal .modal-close").addEventListener("click", closeModal);
    var ov = $("#modal-overlay");
    ov.classList.add("open");
    document.body.style.overflow = "hidden";
  }
  function closeModal() {
    $("#modal-overlay").classList.remove("open");
    document.body.style.overflow = "";
    $all("#modal video").forEach(function (v) { try { v.pause(); } catch (e) {} });
  }

  /* ---------- Render: skills ---------- */
  function renderSkills() {
    var wrap = $("#skills-grid");
    SKILL_GROUPS.forEach(function (g) {
      var rows = g.skills.map(function (s) {
        return '<div class="skill"><div class="row"><span>' + esc(s[0]) + '</span><span class="lvl">' + s[1] + '%</span></div>' +
               '<div class="bar"><i data-level="' + s[1] + '"></i></div></div>';
      }).join("");
      wrap.appendChild(el('<div class="card skill-group reveal"><h3><span class="dot"></span>' + esc(g.name) + "</h3>" + rows + "</div>"));
    });
  }

  /* ---------- Render: services ---------- */
  function renderServices() {
    var wrap = $("#services-grid");
    SERVICES.forEach(function (s) {
      var items = s.items.map(function (i) { return "<li>" + esc(i) + "</li>"; }).join("");
      wrap.appendChild(el(
        '<div class="card service reveal"><div class="ico">' + (ICON[s.icon] || ICON.code) + "</div>" +
        "<h3>" + esc(s.title) + "</h3><p>" + esc(s.desc) + "</p><ul>" + items + "</ul></div>"
      ));
    });
  }

  /* ---------- Render: experience ---------- */
  function renderExperience() {
    var wrap = $("#timeline");
    EXPERIENCE.forEach(function (e) {
      var pts = e.points.map(function (p) { return "<li>" + esc(p) + "</li>"; }).join("");
      wrap.appendChild(el(
        '<div class="tl-item reveal"><div class="card"><span class="when">' + esc(e.when) + "</span>" +
        "<h4>" + esc(e.role) + '</h4><div class="org">' + esc(e.org) + "</div><ul>" + pts + "</ul></div></div>"
      ));
    });
  }

  /* ---------- Scroll reveal ---------- */
  var io;
  function observeReveals() {
    if (!("IntersectionObserver" in window)) { $all(".reveal").forEach(function (r) { r.classList.add("in"); }); return; }
    if (!io) {
      io = new IntersectionObserver(function (entries) {
        entries.forEach(function (en) {
          if (en.isIntersecting) {
            en.target.classList.add("in");
            $all(".bar > i", en.target).forEach(function (b) { b.style.width = b.getAttribute("data-level") + "%"; });
            io.unobserve(en.target);
          }
        });
      }, { threshold: 0.12 });
    }
    $all(".reveal:not(.in)").forEach(function (r) { io.observe(r); });
  }

  /* ---------- Theme ---------- */
  function initTheme() {
    var saved = localStorage.getItem("theme");
    var theme = saved || "dark";
    document.documentElement.setAttribute("data-theme", theme);
    updateThemeIcon(theme);
  }
  function toggleTheme() {
    var cur = document.documentElement.getAttribute("data-theme");
    var next = cur === "dark" ? "light" : "dark";
    document.documentElement.setAttribute("data-theme", next);
    localStorage.setItem("theme", next);
    updateThemeIcon(next);
  }
  function updateThemeIcon(theme) {
    var b = $("#theme-toggle"); if (b) b.innerHTML = theme === "dark" ? ICON.sun : ICON.moon;
  }

  /* ---------- Nav ---------- */
  function initNav() {
    var nav = $("#nav");
    window.addEventListener("scroll", function () {
      nav.classList.toggle("scrolled", window.scrollY > 20);
      $("#to-top").classList.toggle("show", window.scrollY > 500);
      var pos = window.scrollY + 120;
      $all("section[id]").forEach(function (s) {
        var link = $('.nav-links a[href="#' + s.id + '"]');
        if (!link) return;
        if (pos >= s.offsetTop && pos < s.offsetTop + s.offsetHeight) {
          $all(".nav-links a").forEach(function (a) { a.classList.remove("active"); });
          link.classList.add("active");
        }
      });
    });
    $("#hamburger").addEventListener("click", function () { $("#mobile-menu").classList.toggle("open"); });
    $all("#mobile-menu a").forEach(function (a) { a.addEventListener("click", function () { $("#mobile-menu").classList.remove("open"); }); });
  }

  /* ---------- Contact form (mailto) ---------- */
  function initForm() {
    var form = $("#contact-form");
    if (!form) return;
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      var name = $("#c-name").value.trim();
      var email = $("#c-email").value.trim();
      var msg = $("#c-msg").value.trim();
      var subject = encodeURIComponent("Project inquiry from " + (name || "portfolio"));
      var body = encodeURIComponent("Name: " + name + "\nEmail: " + email + "\n\n" + msg);
      window.location.href = "mailto:" + SITE.email + "?subject=" + subject + "&body=" + body;
      $("#form-msg").classList.add("show", "ok");
      $("#form-msg").textContent = "Opening your email app… if it doesn't open, email me directly at " + SITE.email;
    });
  }

  /* ---------- Boot ---------- */
  document.addEventListener("DOMContentLoaded", function () {
    // inject icons into static spots
    $all("[data-icon]").forEach(function (n) { n.innerHTML = ICON[n.getAttribute("data-icon")] || ""; });
    $("#theme-toggle").innerHTML = ICON.sun;
    $("#hamburger").innerHTML = ICON.menu;
    $("#to-top").innerHTML = ICON.top;

    renderFilters();
    renderProjects("All");
    renderSkills();
    renderServices();
    renderExperience();

    initTheme();
    initNav();
    initForm();
    observeReveals();

    $("#year").textContent = new Date().getFullYear();
    $("#theme-toggle").addEventListener("click", toggleTheme);
    $("#to-top").addEventListener("click", function () { window.scrollTo({ top: 0, behavior: "smooth" }); });
    $("#modal-overlay").addEventListener("click", function (e) { if (e.target === this) closeModal(); });
    document.addEventListener("keydown", function (e) { if (e.key === "Escape") closeModal(); });
  });
})();
